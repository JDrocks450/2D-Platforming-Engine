﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperMario.LevelLoader
{
    public class LevelData
    {
        const int BLOCK_SIZE = 26;
        const int SEP_INDEX = 18;

        public enum OBJ_TABLE
        {
            EMPTY = 0,
            BLOCK = 1
        }

        int[] dataLengthTable = new int[] { 8, 8, 4, 4 };

        byte[] fileData;

        public void LoadFile(string url)
        {
            if (true)
            {
                using (var file = File.OpenWrite(url))
                {
                    int x = 1000;
                    int y = 500;
                    byte id = 1;
                    string Xhex = x.ToString("X8");
                    string Yhex = y.ToString("X8");
                    string idHex = id.ToString("X4");
                    var bytes = ASCIIEncoding.ASCII.GetBytes(" ");
                    file.Write(bytes, 0, bytes.Length);
                    bytes = ASCIIEncoding.ASCII.GetBytes(Xhex);
                    file.Write(bytes, 0, bytes.Length);
                    bytes = ASCIIEncoding.ASCII.GetBytes(Yhex);
                    file.Write(bytes, 0, bytes.Length);
                    bytes = ASCIIEncoding.ASCII.GetBytes(idHex);
                    file.Write(bytes, 0, bytes.Length);
                    bytes = ASCIIEncoding.ASCII.GetBytes(((int)0).ToString("X4"));
                    file.Write(bytes, 0, bytes.Length);
                }
            }
            using (var file = File.OpenRead(url))
            {
                fileData = new byte[file.Length];
                file.Read(fileData, 0, fileData.Length);
            }
            ReadData();
        }

        //XXXXXXXXYYYYYYYY::OOOONNNN
        //where: X = X coordinate, Y = Y coordinate, :: = separator, O = OBJID, N = not used yet

        void ReadData()
        {
            if (Encoding.ASCII.GetChars(new byte[] { fileData[0] }).First() != ' ')
                throw new Exception("Level not formatted");           
            char[] block = new char[BLOCK_SIZE];
            int i = BLOCK_SIZE+1;
            foreach (byte b in fileData)
            {
                var c = Encoding.ASCII.GetChars(new byte[1] { b }).First();
                if (c == ' ') //new block start
                {
                    block = new char[BLOCK_SIZE];
                    i = 0;
                }
                else if (i < BLOCK_SIZE)
                {
                    block[i] = c;
                    i++;
                }
                if (i == BLOCK_SIZE)
                    Parse(block);
            }            
        }

        void Parse(char[] block)
        {
            int X = 0;
            int Y = 0;
            byte OBJID = 0;
            int offset = 0;
            for (int i = 0; i < dataLengthTable.Length; i++)
            {
                var data = new string(block.Skip(offset).Take(dataLengthTable[i]).ToArray());
                offset += dataLengthTable[i];
                int intFromHex = 0;
                byte byteFromHex = 0;
                if (dataLengthTable[i] == 8)
                    intFromHex = int.Parse(data, System.Globalization.NumberStyles.HexNumber);
                if (dataLengthTable[i] == 4)
                    byteFromHex = byte.Parse(data, System.Globalization.NumberStyles.HexNumber);
                switch (i)
                {                    
                    case 0:
                        X = intFromHex;
                        break;
                    case 1:
                        Y = intFromHex;
                        break;
                    case 2:
                        OBJID = byteFromHex;
                        break;
                }               
            }                
        }
    }
}
